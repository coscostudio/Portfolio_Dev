export function isAboveMinViewport(): boolean {
  return window.innerWidth > 480;
}
