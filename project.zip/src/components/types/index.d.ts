declare global {
  interface Window {
    splide: {
      Extensions: any;
    };
  }
}

export {};
